# Hand Gesture Control

A real-time hand gesture detection system via webcam that converts gestures into
documented, machine-readable control commands, built on a fully extensible
(plugin-based) architecture in Python.

## Key Features

- **Full, independent support for both hands at once**: each hand (left/right) keeps
  completely separate memory and history - meaning detection of, say, a "fist" or a
  "move right" works independently and without interference for each hand.
- **Geometric shape between the two hands** (like the well-known MediaPipe demos):
  when both hands are seen at the same time, a quadrilateral is drawn between them that
  changes shape as the hands move apart/together or rotate; its size, center, and angle
  are also emitted as a documented output command (e.g. usable for zoom control).
- **Live browser viewer** (like MediaPipe's own demo): running the program automatically
  opens a page at `http://127.0.0.1:8000` that shows the camera feed with hand landmark
  points and connection lines in real time, along with a live panel of output commands.
- **Real-time API (WebSocket) for connecting any other program**: at `ws://127.0.0.1:8765`
  - both the same browser page and any other software on the system (robotics, a Python
  script, Unity, Node.js, etc.) can connect to this one channel simultaneously and
  receive the JSON commands.
- **Fixed numeric code for every command**: each gesture is numbered starting from zero
  (e.g. index finger swipe down = `0`, swipe up = `1`, ...). The default console output
  prints just this number.
- **Real-time and lightweight**: built on Google's MediaPipe Hands - runs entirely on
  CPU, no GPU required.
- **Full hand rig data stream**: exactly like MediaPipe's own raw output (21 landmarks +
  each finger's curl angle), but wrapped in a standard, documented command - for anyone
  who wants to drive a 3D model/character rig/robotic hand from the raw data.
- **Fully extensible**: adding a new single-hand or two-hand gesture only requires
  writing one class, with no changes to the core of the program.
- **Automatic documentation**: a script generates Markdown and JSON Schema from the
  command registry.
- **Fully configurable via YAML**, with no code changes needed (thresholds, rates,
  enabling/disabling each output).

## Why MediaPipe?

MediaPipe Hands is a model Google specifically optimized for real-time execution on CPU
(even on mobile). With the lightweight `hand_landmarker` model, this system runs even on
weak hardware - unlike approaches like OpenPose or custom CNN models, which usually need
a GPU.

> **Note on API version:** since early 2023, Google has gradually deprecated the older
> `mp.solutions.hands` API, and in recent pip releases (0.10.3x and later) this API has
> been fully removed. This project uses the new, official **Tasks** API
> (`mediapipe.tasks.python.vision.HandLandmarker`), which is stable and actively
> maintained. A small model file (`hand_landmarker.task`, about 7-10 MB) is
> automatically downloaded from Google's servers and cached in the `models/` folder the
> first time the program runs (this requires internet access, just for that first run).

## Installation

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running

```bash
python main.py
```

Running this command activates three channels at once:

| Channel | Address | Purpose |
|---|---|---|
| Web viewer | `http://127.0.0.1:8000` | View the camera feed + hand landmarks + command log (opens automatically in the browser) |
| Real-time API | `ws://127.0.0.1:8765` | Connect any other program (robotics, a script, other software) to receive commands |
| Local window | - | The classic OpenCV window, for quick debugging without needing a browser |

Command-line options:
- `--no-window` : run without the local OpenCV window (the web viewer and API stay active)
- `--no-web` : run without the web server, even if it's enabled in the config (local window + API only)
- `--config path/to/file.yaml` : use a different config file

To exit: press `q`/`Esc` in the local window, or `Ctrl+C` in the terminal

## Project Structure

```
hand_gesture_control/
├── config/gestures.yaml          # all thresholds and output settings - no code changes needed
├── core/
│   ├── landmarks.py              # geometry functions over the 21 hand landmarks
│   ├── command.py                # Command structure + central documentation registry
│   ├── gesture_base.py           # base class for every single-hand detector (extension point)
│   ├── two_hand_base.py          # base class for every two-hand detector (extension point)
│   ├── two_hand_geometry.py      # pure geometry functions for the shape between two hands
│   ├── hand_tracker.py           # wrapper around MediaPipe Hands + skeleton/two-hand shape drawing
│   ├── dispatcher.py             # runs detectors (independent memory per hand) + dispatches to outputs
│   ├── gestures/                 # one file = one gesture
│   │   ├── movement.py           # left/right/up/down/forward/backward (whole hand)
│   │   ├── fist.py               # making a fist / opening the hand
│   │   ├── pinch_rub.py          # bringing thumb and index together and rubbing them
│   │   ├── finger_point.py       # horizontal/vertical index finger movement
│   │   ├── thumbs.py             # showing the thumb
│   │   ├── open_palm_swipe.py    # open hand moving right
│   │   ├── hand_rig.py           # full hand skeleton data stream on every frame
│   │   └── two_hand_frame.py     # geometric shape between two hands (two-hand)
│   ├── output/
│   │   ├── base_sink.py          # base output interface (extension point)
│   │   ├── console_sink.py
│   │   ├── json_log_sink.py      # real-time save to a JSON Lines file
│   │   └── websocket_sink.py     # the main real-time API - broadcasts to any other program
│   └── web/
│       ├── broadcaster.py        # holds the latest frame for live streaming
│       ├── server.py             # Flask server (page + MJPEG stream)
│       └── templates/index.html  # the live browser viewer page
├── docs/
│   ├── generate_docs.py          # automatic documentation generation
│   ├── commands.md               # (generated) table of every command
│   └── commands.schema.json      # (generated) JSON schema of every command
├── examples/
│   ├── custom_gesture_example.py       # example: adding a new single-hand gesture
│   └── custom_two_hand_example.py      # example: adding a new two-hand capability
└── main.py                       # entry point
```

## Currently Supported Gestures

The complete, up-to-date list is always generated in `docs/commands.md` (by running the
command below). Summary:

| Category | Gesture | Command ID |
|---|---|---|
| Overall hand movement | left / right / up / down / forward / backward | `hand.move.*` |
| Gesture | making a fist / opening the hand | `hand.fist`, `hand.open` |
| Gesture | bringing thumb and index together and rubbing | `hand.pinch.start/rub/end` |
| Gesture | horizontal/vertical index finger movement | `finger.swipe.*` |
| Gesture | showing the thumb | `hand.thumb.show/hide` |
| Gesture | open hand moving right | `hand.open_palm.swipe_right` |
| Raw data | full hand rig (21 points + each finger's angles) | `hand.rig.frame` |
| Two-hand | geometric shape between two hands (size/center/angle) | `hands.pair.frame` |

Every detector above works for **both hands, completely independently** (each hand's
memory/history is separate); `hands.pair.frame` is the one exception, and is only active
when both hands are seen at the same time.

## Generating Documentation

```bash
python docs/generate_docs.py
```

This command updates `docs/commands.md` (a readable table) and
`docs/commands.schema.json` (for machine consumption) from the command registry - any
new gesture you add will automatically appear in the documentation.

## Numeric Code System

In addition to a readable text identifier (`command_id`), every command has a fixed,
unique integer starting from zero (the `code` field). These codes are set explicitly
right where each command is defined (inside each `core/gestures/*.py` file, in the
`CommandRegistry.register(...)` call) - not automatically - so they always stay fixed
and under your control. The complete, up-to-date table is in `docs/commands.md`; a few
examples:

| Code | Gesture |
|---|---|
| `0` | index finger swipe down |
| `1` | index finger swipe up |
| `2` | index finger swipe left |
| `3` | index finger swipe right |
| `4` | making a fist |
| `6`–`11` | overall hand movement: left, right, up, down, forward, backward |
| `19` | geometric shape between two hands (`hands.pair.frame`) |

**The console output defaults to numeric mode** - meaning that running `python main.py`,
whenever a gesture is detected, only that number is printed on a line:

```
0
0
7
4
```

This behavior can be changed in `config/gestures.yaml`:

```yaml
output:
  console:
    mode: numeric   # print only the number (default)
    # mode: full    # a full, readable line for debugging (code + id + labels + parameters)
```

The JSON log file and the WebSocket output both carry the same numeric code in each
command's `code` field - meaning any other software connecting to these outputs can
just read that number and ignore the rest of the information (labels, parameters).

## Output Structure of Each Command (Command)

```json
{
  "command_id": "hand.move.right",
  "code": 7,
  "label_fa": "Hand Move Right",
  "label_en": "Hand Move Right",
  "category": "movement",
  "params": {"speed": 0.041},
  "confidence": 1.0,
  "hand": "Right",
  "timestamp": 1732650000.123
}
```

The `hand.rig.frame` command (full rig data) has the same structure, just its `params`
contains every one of the 21 points, each joint's name, each finger's state
(extended/curled), and curl angle - full details in `docs/commands.md`.

## Adding a New Gesture

No file in `core/` needs to be changed:

```python
# 1) Build a new class (full example in examples/custom_gesture_example.py)
from core.gesture_base import GestureDetector
from core.command import Command, CommandRegistry
from core.landmarks import finger_states

# Code 20, since codes 0 through 19 are already used - every code must be unique
CommandRegistry.register("hand.peace_sign", 20, "Peace Sign", "Peace Sign", "gesture", "Description...", {})

class PeaceSignDetector(GestureDetector):
    def update(self, points, frame_shape, timestamp, hand_label):
        states = finger_states(points)
        if states["index"] and states["middle"] and not states["ring"] and not states["pinky"]:
            return [CommandRegistry.make_command("hand.peace_sign", hand=hand_label)]
        return []

# 2) In main.py, add it to build_detectors:
#    PeaceSignDetector(config)
```

If you pick a duplicate code (say, reuse `4`), `CommandRegistry.register` stops the
program right at load time with a clear error - so code conflicts never pass silently.

**Adding a two-hand capability** (something that needs both hands at the same time,
like the geometric shape between two hands) is similar - just inherit from
`TwoHandDetector` (instead of `GestureDetector`), and its `update` method receives
`left_points`/`right_points` together - a full example is in
`examples/custom_two_hand_example.py`.

## Connecting Another Program to the Output Commands (WebSocket)

With `output.websocket.enabled: true` in `config/gestures.yaml`, any program can connect
to `ws://127.0.0.1:8765` and receive the JSON commands in real time. Example Python
client:

```python
import asyncio, json, websockets

async def listen():
    async with websockets.connect("ws://127.0.0.1:8765") as ws:
        async for message in ws:
            cmd = json.loads(message)
            print(cmd["command_id"], cmd["params"])
            # Turn the command into a real action in your own system here
            # e.g.: if cmd["command_id"] == "hand.move.right": robot.move_right(cmd["params"]["speed"])

asyncio.run(listen())
```

## Performance Notes for Weak Systems

- `camera.model_complexity: 0` in the settings (the lightweight MediaPipe model) - this
  is already the default.
- If you only need one hand, set `camera.max_num_hands: 1` in the settings for more
  speed (the default is `2`, to enable both hands and the shape between them).
- Keep the camera resolution low (default 640x480; try 320x240 on a very weak system).
- Use `--no-window` to reduce the CPU cost of rendering and displaying the image.
- Lower `hand_rig.stream_rate_hz` and `two_hand_frame.stream_rate_hz` if needed, to
  reduce log/network volume.

## Known Limitations (for transparency)

- **The first run requires internet access** to download the `hand_landmarker.task`
  model file; after that, it works fully offline. If you'd like to download it manually
  ahead of time, get the file from
  `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task`
  and place it at `models/hand_landmarker.task` (or point to it via `camera.model_path`
  in `config/gestures.yaml`).
- Forward/backward detection isn't precise, since a single monocular camera has no real
  depth sensor; the apparent change in hand size is used as an approximation.
- The detection thresholds (distance, angle, speed) are tuned to typical values, but
  depending on lighting, camera angle, and a person's hand size, they may need fine
  adjustment in `config/gestures.yaml`.
- The geometric shape between two hands (`hands.pair.frame`) is built from the wrist and
  index finger base of each hand; if you'd like to use different landmarks, change
  `TOP_LANDMARK_INDEX` in `core/two_hand_geometry.py`.
