import time
from typing import Callable, Dict, List, Set

from .command import Command
from .landmarks import to_points
from .gesture_base import GestureDetector
from .two_hand_base import TwoHandDetector


class GestureManager:
    """
    Runs single-hand and two-hand detectors on every frame and dispatches output
    commands to the sinks.

    Important note about two-hand support: each single-hand detector (e.g.
    HandMovementDetector) keeps internal state (movement history, previous state, etc).
    If a single shared instance were used for both hands, the two hands' histories would
    get mixed together and detection would be wrong. That's why GestureManager, instead
    of taking a fixed list of detectors, takes a "factory" (detector_factory) and builds
    a completely fresh, independent set of detectors the first time each hand label
    ('Left'/'Right') is seen.
    """

    def __init__(self,
                 detector_factory: Callable[[], List[GestureDetector]],
                 two_hand_detectors: List[TwoHandDetector],
                 sinks: list):
        self.detector_factory = detector_factory
        self.two_hand_detectors = two_hand_detectors
        self.sinks = sinks
        self._detectors_by_hand: Dict[str, List[GestureDetector]] = {}

    def _get_hand_detectors(self, hand_label: str) -> List[GestureDetector]:
        if hand_label not in self._detectors_by_hand:
            self._detectors_by_hand[hand_label] = self.detector_factory()
        return self._detectors_by_hand[hand_label]

    def process_hand(self, hand_landmarks, frame_shape, hand_label: str) -> List[Command]:
        points = to_points(hand_landmarks)
        timestamp = time.time()
        detectors = self._get_hand_detectors(hand_label)

        commands: List[Command] = []
        for detector in detectors:
            try:
                commands.extend(detector.update(points, frame_shape, timestamp, hand_label))
            except Exception as e:
                print(f"[GestureManager] Error in detector '{detector.name}' (hand {hand_label}): {e}")

        for cmd in commands:
            self._emit(cmd)
        return commands

    def process_pair(self, left_hand_landmarks, right_hand_landmarks, frame_shape) -> List[Command]:
        """Only call this when both hands ('Left' and 'Right') were seen in this same frame."""
        left_points = to_points(left_hand_landmarks)
        right_points = to_points(right_hand_landmarks)
        timestamp = time.time()

        commands: List[Command] = []
        for detector in self.two_hand_detectors:
            try:
                commands.extend(detector.update(left_points, right_points, frame_shape, timestamp))
            except Exception as e:
                print(f"[GestureManager] Error in two-hand detector '{detector.name}': {e}")

        for cmd in commands:
            self._emit(cmd)
        return commands

    def reset_pair(self):
        """Called once both hands are no longer seen at the same time, to reset two-hand detector state."""
        for detector in self.two_hand_detectors:
            detector.reset()

    def end_frame(self, seen_hand_labels: Set[str]):
        """
        Called at the end of every frame (whether zero, one, or two hands were seen);
        resets the internal state of any hand that wasn't seen in this frame - e.g. if
        the right hand leaves the frame while the left hand stays, only the right hand's
        detectors get reset.
        """
        for label, detectors in self._detectors_by_hand.items():
            if label not in seen_hand_labels:
                for d in detectors:
                    d.reset()

    def _emit(self, command: Command):
        for sink in self.sinks:
            if not sink.should_emit(command):
                continue
            try:
                sink.emit(command)
            except Exception as e:
                print(f"[GestureManager] Error in sink '{sink.__class__.__name__}': {e}")

    def close(self):
        for sink in self.sinks:
            sink.close()
