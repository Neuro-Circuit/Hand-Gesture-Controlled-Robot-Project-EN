"""Output sinks (Console, JSON Log, WebSocket, ...)."""
