from abc import ABC, abstractmethod
from typing import Iterable, Optional
from ..command import Command


class OutputSink(ABC):
    """
    Base output interface. To connect this system to another piece of software
    (robotics, a game, home-automation, 3D animation, etc.) simply inherit from this
    class and implement the emit method to forward the command to the target system.
    No changes to GestureManager or main.py are needed.

    The categories parameter allows filtering by command category; for example, the
    console can be limited to only the "gesture"/"movement" categories, while the
    high-volume "rig" frames are sent only to the log/WebSocket.
    """

    def __init__(self, categories: Optional[Iterable[str]] = None):
        self.categories = set(categories) if categories else None

    def should_emit(self, command: Command) -> bool:
        return self.categories is None or command.category in self.categories

    @abstractmethod
    def emit(self, command: Command):
        raise NotImplementedError

    def close(self):
        pass
