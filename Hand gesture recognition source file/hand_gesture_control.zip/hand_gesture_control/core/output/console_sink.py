from .base_sink import OutputSink
from ..command import Command


class ConsoleSink(OutputSink):
    """
    Prints commands to the console - with two modes:

    mode="numeric" (default): only the command's numeric code is printed on a line, e.g.:
        0
        1
        4
    This mode is designed for simple integration with scripts or other systems (like
    reading from a pipe with a serial/Arduino program).

    mode="full": a fuller, more readable output including the code, text identifier,
    Persian/English labels, and parameters (useful for developer debugging).
    """

    def __init__(self, categories=None, mode: str = "numeric"):
        super().__init__(categories)
        self.mode = mode

    def emit(self, command: Command):
        if self.mode == "numeric":
            print(command.code)
        else:
            params = f" params={command.params}" if command.params else ""
            print(f"[{command.timestamp:.2f}] code={command.code:<3d} {command.command_id:28s} "
                  f"({command.label_fa} / {command.label_en}) hand={command.hand}{params}")
