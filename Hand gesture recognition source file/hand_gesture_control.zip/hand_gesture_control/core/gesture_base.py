from abc import ABC, abstractmethod
from typing import List
from .command import Command


class GestureDetector(ABC):
    """
    Base class for every single-hand gesture detector.

    To add a new gesture to the system:
      1. Create a new class that inherits from GestureDetector.
      2. Register its output command(s) with CommandRegistry.register(...).
      3. Implement the update method.
      4. Add an instance of the class to the build_detectors list in main.py.

    No changes to the core of the program (dispatcher, hand_tracker, main loop) are needed.
    Full example: examples/custom_gesture_example.py
    """

    name: str = "base"

    def __init__(self, config: dict):
        self.config = config

    @abstractmethod
    def update(self, points, frame_shape, timestamp: float, hand_label: str) -> List[Command]:
        """
        points: list of 21 normalized (x, y, z) hand landmarks, in standard MediaPipe order
        frame_shape: (height, width, channels) of the current camera frame
        timestamp: unix time of the moment this frame was processed
        hand_label: "Left" or "Right"

        Returns: a list of Command objects (can be empty on most frames)
        """
        raise NotImplementedError

    def reset(self):
        """Called when the hand leaves the camera's view, to clear internal state."""
        pass
