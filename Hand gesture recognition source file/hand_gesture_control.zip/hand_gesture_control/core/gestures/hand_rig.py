from typing import List
from ..gesture_base import GestureDetector
from ..command import Command, CommandRegistry
from ..landmarks import finger_states, finger_curl_angle, palm_center, hand_size, LANDMARK_NAMES, FINGER_JOINTS

CommandRegistry.register(
    "hand.rig.frame", 18, "Full Hand Rig Frame", "Full Hand Rig Frame", "rig",
    "The position of every one of the 21 hand landmarks (exactly matching MediaPipe's "
    "raw output) along with each finger's curl angle and extended/curled state, emitted "
    "on every frame (or at a capped rate). For connecting to a 3D model/character rig, "
    "robotics, or any consumer that needs the raw data.",
    {
        "landmarks": "Array of 21 normalized [x, y, z] points, in standard MediaPipe order",
        "landmarks_named": "The same 21 points keyed by joint name (e.g. INDEX_TIP)",
        "finger_states": "Boolean dictionary of extended/curled for each finger",
        "finger_curl_angles": "Each finger's curl angle in degrees (180 = fully straight)",
        "palm_center": "[x, y, z] center of the palm",
        "hand_size": "Approximate hand size - usable to estimate depth/distance from the camera",
    },
)


class HandRigEmitter(GestureDetector):
    """
    Unlike the other detectors, which only announce the moment a specific event occurs,
    this class emits the full hand skeleton data as a standard Command on every frame
    (at a configurable stream_rate_hz) - meaning whatever MediaPipe gives raw is,
    here, documented and ready for real-time consumption by other systems.
    """
    name = "hand_rig"

    def __init__(self, config: dict):
        super().__init__(config)
        cfg = config.get("hand_rig", {})
        self.enabled = cfg.get("enabled", True)
        self.stream_rate_hz = cfg.get("stream_rate_hz", 15)
        self._min_interval = 1.0 / max(self.stream_rate_hz, 0.001)
        self._last_emit = 0.0

    def update(self, points, frame_shape, timestamp, hand_label) -> List[Command]:
        if not self.enabled:
            return []
        if timestamp - self._last_emit < self._min_interval:
            return []
        self._last_emit = timestamp

        states = finger_states(points)
        curl_angles = {f: round(finger_curl_angle(points, f), 1) for f in FINGER_JOINTS}
        landmarks = [[round(p[0], 5), round(p[1], 5), round(p[2], 5)] for p in points]
        landmarks_named = {LANDMARK_NAMES[i]: landmarks[i] for i in range(len(landmarks))}

        return [CommandRegistry.make_command(
            "hand.rig.frame",
            params={
                "landmarks": landmarks,
                "landmarks_named": landmarks_named,
                "finger_states": states,
                "finger_curl_angles": curl_angles,
                "palm_center": list(palm_center(points)),
                "hand_size": round(hand_size(points), 5),
            },
            hand=hand_label,
        )]
