from typing import List
from ..two_hand_base import TwoHandDetector
from ..command import Command, CommandRegistry
from ..two_hand_geometry import compute_pair_quad

CommandRegistry.register(
    "hands.pair.frame", 19, "Two-Hand Frame Shape", "Two-Hand Frame Shape", "pair",
    "When both hands are seen at the same time, a quadrilateral is built between "
    "reference points on the two hands (wrist and index finger base) that changes "
    "shape/size/angle as the hands move - exactly the 'two-hand framing' pattern seen "
    "in MediaPipe demos.",
    {
        "corners": "Four corner points in order [bottom-left, top-left, top-right, bottom-right], each [x, y]",
        "width": "Normalized distance between the two wrists (e.g. usable for zoom control)",
        "height": "Average distance from wrist to index finger base for each hand",
        "center": "[x, y] center of the quadrilateral",
        "angle_deg": "Tilt angle of the line connecting the two hands, in degrees",
        "area": "Approximate area of the quadrilateral (normalized, between 0 and 1)",
    },
)


class TwoHandFrameDetector(TwoHandDetector):
    """
    Only active when both hands are seen at the same time. At a configurable rate
    (like hand_rig) it emits quadrilateral geometry data between the two hands - both
    for consumption by other systems (e.g. zoom control via the distance between the
    hands) and for the visual drawing in core/hand_tracker.py.
    """
    name = "two_hand_frame"

    def __init__(self, config: dict):
        super().__init__(config)
        cfg = config.get("two_hand_frame", {})
        self.stream_rate_hz = cfg.get("stream_rate_hz", 15)
        self._min_interval = 1.0 / max(self.stream_rate_hz, 0.001)
        self._last_emit = 0.0

    def update(self, left_points, right_points, frame_shape, timestamp) -> List[Command]:
        if timestamp - self._last_emit < self._min_interval:
            return []
        self._last_emit = timestamp
        quad = compute_pair_quad(left_points, right_points)
        return [CommandRegistry.make_command("hands.pair.frame", params=quad, hand="Both")]
