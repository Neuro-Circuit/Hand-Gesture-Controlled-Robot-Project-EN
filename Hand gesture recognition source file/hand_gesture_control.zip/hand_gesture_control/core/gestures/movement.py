from collections import deque
from typing import List
from ..gesture_base import GestureDetector
from ..command import Command, CommandRegistry
from ..landmarks import palm_center, hand_size

CommandRegistry.register("hand.move.left", 6, "Hand Move Left", "Hand Move Left", "movement",
                          "The palm center moves to the left", {"speed": "float"})
CommandRegistry.register("hand.move.right", 7, "Hand Move Right", "Hand Move Right", "movement",
                          "The palm center moves to the right", {"speed": "float"})
CommandRegistry.register("hand.move.up", 8, "Hand Move Up", "Hand Move Up", "movement",
                          "The palm center moves upward", {"speed": "float"})
CommandRegistry.register("hand.move.down", 9, "Hand Move Down", "Hand Move Down", "movement",
                          "The palm center moves downward", {"speed": "float"})
CommandRegistry.register("hand.move.forward", 10, "Hand Move Forward", "Hand Move Forward", "movement",
                          "The hand moves closer to the camera (based on the hand appearing larger)", {"speed": "float"})
CommandRegistry.register("hand.move.backward", 11, "Hand Move Backward", "Hand Move Backward", "movement",
                          "The hand moves away from the camera (based on the hand appearing smaller)", {"speed": "float"})


class HandMovementDetector(GestureDetector):
    """
    Detects overall hand movement (regardless of finger pose) in 6 directions.
    Forward/backward is estimated from the apparent change in hand size, since there's
    no real depth sensor.
    """
    name = "hand_movement"

    def __init__(self, config: dict):
        super().__init__(config)
        cfg = config.get("movement", {})
        self.history_len = cfg.get("history_len", 6)
        self.move_th = cfg.get("move_threshold", 0.035)
        self.depth_th = cfg.get("depth_threshold", 0.06)
        self.cooldown = cfg.get("cooldown", 0.35)
        self._pos_hist = deque(maxlen=self.history_len)
        self._size_hist = deque(maxlen=self.history_len)
        self._last_emit = 0.0

    def reset(self):
        self._pos_hist.clear()
        self._size_hist.clear()

    def update(self, points, frame_shape, timestamp, hand_label) -> List[Command]:
        center = palm_center(points)
        size = hand_size(points)
        self._pos_hist.append(center)
        self._size_hist.append(size)

        if len(self._pos_hist) < self.history_len:
            return []
        if timestamp - self._last_emit < self.cooldown:
            return []

        dx = self._pos_hist[-1][0] - self._pos_hist[0][0]
        dy = self._pos_hist[-1][1] - self._pos_hist[0][1]
        dsize = self._size_hist[-1] - self._size_hist[0]

        commands = []
        if abs(dsize) > self.depth_th:
            cid = "hand.move.forward" if dsize > 0 else "hand.move.backward"
            commands.append(CommandRegistry.make_command(
                cid, params={"speed": round(abs(dsize), 4)}, hand=hand_label))
        elif abs(dx) > abs(dy) and abs(dx) > self.move_th:
            cid = "hand.move.right" if dx > 0 else "hand.move.left"
            commands.append(CommandRegistry.make_command(
                cid, params={"speed": round(abs(dx), 4)}, hand=hand_label))
        elif abs(dy) > self.move_th:
            cid = "hand.move.down" if dy > 0 else "hand.move.up"
            commands.append(CommandRegistry.make_command(
                cid, params={"speed": round(abs(dy), 4)}, hand=hand_label))

        if commands:
            self._last_emit = timestamp
            self._pos_hist.clear()
            self._size_hist.clear()
        return commands
