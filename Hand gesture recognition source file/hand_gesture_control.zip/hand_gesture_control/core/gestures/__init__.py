"""All of the system's built-in gesture detectors live in this package."""
