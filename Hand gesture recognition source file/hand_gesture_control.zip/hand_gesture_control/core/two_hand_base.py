from abc import ABC, abstractmethod
from typing import List
from .command import Command


class TwoHandDetector(ABC):
    """
    Base class for detectors that need both hands at the same time - for example,
    to build a geometric shape between the two hands, or measure the distance/angle
    between them.

    Unlike GestureDetector (which only receives a single hand's points), the update
    method here receives both hands' points simultaneously. GestureManager only calls
    these detectors when both hands ('Left' and 'Right') were seen in the same frame.

    To add a new two-hand capability, inherit from this class (see the example in
    core/gestures/two_hand_frame.py) and add an instance of it to build_two_hand_detectors
    in main.py.
    """

    name: str = "two_hand_base"

    def __init__(self, config: dict):
        self.config = config

    @abstractmethod
    def update(self, left_points, right_points, frame_shape, timestamp: float) -> List[Command]:
        """
        left_points / right_points: each a list of 21 normalized (x, y, z) points for one hand.
        The left/right ordering is guaranteed to match the actual hand handedness.
        """
        raise NotImplementedError

    def reset(self):
        """Called once both hands are no longer seen at the same time (one of the two left the frame)."""
        pass
