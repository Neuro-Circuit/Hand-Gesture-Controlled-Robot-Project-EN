"""Core of the hand gesture detection system."""
