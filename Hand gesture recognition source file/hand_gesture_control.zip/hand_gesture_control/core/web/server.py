"""
Lightweight local web server (Flask) with two jobs:

  1. Serves a page at a fixed address (default http://127.0.0.1:8000) showing the live
     camera feed with hand landmark points and connection lines (very similar to
     MediaPipe's own demo), along with a live panel of output commands.
  2. The existing WebSocket (core/output/websocket_sink.py) is the main real-time API;
     this server is just a visual front-end on the same channel - any other program
     (robotics, a script, other software) can independently and simultaneously connect
     to the same WebSocket alongside this page.

Runs in a separate (daemon) thread so the main image-processing loop is not blocked.
"""
import logging
import threading
import time
import webbrowser

from flask import Flask, Response, render_template

from .broadcaster import FrameBroadcaster

_MJPEG_BOUNDARY = b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"


def create_app(broadcaster: FrameBroadcaster, web_host: str, web_port: int,
               ws_host: str, ws_port: int) -> Flask:
    app = Flask(__name__)
    logging.getLogger("werkzeug").setLevel(logging.ERROR)  # silence the high-volume MJPEG request logs

    @app.route("/")
    def index():
        return render_template("index.html", web_host=web_host, web_port=web_port,
                                ws_host=ws_host, ws_port=ws_port)

    @app.route("/video_feed")
    def video_feed():
        def generate():
            while True:
                jpeg = broadcaster.get_jpeg()
                if jpeg is not None:
                    yield _MJPEG_BOUNDARY + jpeg + b"\r\n"
                time.sleep(0.03)  # cap streaming to the browser at ~30 frames per second

        return Response(generate(), mimetype="multipart/x-mixed-replace; boundary=frame")

    return app


def start_web_server(broadcaster: FrameBroadcaster, config: dict) -> threading.Thread:
    """
    Runs the server in a background thread, and if auto_open_browser is enabled,
    opens the system's default browser to the viewer's address.
    """
    out_cfg = config.get("output", {})
    web_cfg = out_cfg.get("web", {})
    ws_cfg = out_cfg.get("websocket", {})

    web_host = web_cfg.get("host", "127.0.0.1")
    web_port = web_cfg.get("port", 8000)
    ws_host = ws_cfg.get("host", "127.0.0.1")
    ws_port = ws_cfg.get("port", 8765)

    app = create_app(broadcaster, web_host, web_port, ws_host, ws_port)

    def run():
        app.run(host=web_host, port=web_port, threaded=True, debug=False, use_reloader=False)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()

    url = f"http://{web_host}:{web_port}"
    print(f"[WebServer] Live viewer available at: {url}")

    if web_cfg.get("auto_open_browser", True):
        def _open():
            time.sleep(1.0)  # brief pause to let the server come up
            webbrowser.open(url)
        threading.Thread(target=_open, daemon=True).start()

    return thread
