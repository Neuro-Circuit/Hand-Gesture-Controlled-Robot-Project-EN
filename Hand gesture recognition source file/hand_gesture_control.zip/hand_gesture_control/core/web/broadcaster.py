import threading
from typing import Optional

import cv2


class FrameBroadcaster:
    """
    Holds the latest annotated frame (camera + hand skeleton points/lines) as JPEG,
    thread-safely. The main processing loop (main.py) updates this on every frame, and
    the web server (core/web/server.py) reads this same buffer to stream live MJPEG to
    the browser.

    A simple lock is enough since only the most recent frame matters; no queue is needed.
    """

    def __init__(self, jpeg_quality: int = 80):
        self._lock = threading.Lock()
        self._jpeg_bytes: Optional[bytes] = None
        self.jpeg_quality = jpeg_quality

    def update(self, frame_bgr) -> None:
        ok, buf = cv2.imencode(".jpg", frame_bgr, [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality])
        if not ok:
            return
        with self._lock:
            self._jpeg_bytes = buf.tobytes()

    def get_jpeg(self) -> Optional[bytes]:
        with self._lock:
            return self._jpeg_bytes
