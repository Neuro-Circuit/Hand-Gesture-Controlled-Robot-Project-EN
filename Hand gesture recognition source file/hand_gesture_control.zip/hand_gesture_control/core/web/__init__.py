"""Local web server for the live camera view + real-time command panel in the browser."""
