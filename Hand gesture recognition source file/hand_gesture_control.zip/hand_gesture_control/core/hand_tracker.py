"""
Wrapper around the MediaPipe Tasks HandLandmarker.

Important note: starting in early 2023, MediaPipe gradually deprecated the older
'mp.solutions.hands' API, and in recent pip releases (e.g. 0.10.33) it has been fully
removed and is no longer available (causes an AttributeError). For this reason, this
module uses the new, official "Tasks" API, which requires a model file
(hand_landmarker.task); this file is automatically downloaded from Google's servers on
first run and cached in the models/ folder.
"""
import os
import time
import urllib.request

import cv2
import mediapipe as mp

from .landmarks import to_points
from .two_hand_geometry import compute_pair_quad

BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
             "hand_landmarker/float16/latest/hand_landmarker.task")
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
MODEL_PATH = os.path.join(MODEL_DIR, "hand_landmarker.task")

# Standard connections between the 21 hand landmarks, for drawing the skeleton on the image.
# Since the old drawing_utils (mp.solutions.drawing_utils) is no longer available, these
# connections are drawn directly with OpenCV.
HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),          # thumb
    (0, 5), (5, 6), (6, 7), (7, 8),          # index
    (5, 9), (9, 10), (10, 11), (11, 12),     # middle
    (9, 13), (13, 14), (14, 15), (15, 16),   # ring
    (13, 17), (17, 18), (18, 19), (19, 20),  # pinky
    (0, 17),                                  # wrist to pinky base
]


def ensure_model_downloaded(path: str = MODEL_PATH, url: str = MODEL_URL) -> str:
    """If the model hasn't been downloaded yet, download it once (about 7-10 MB) from Google's servers."""
    if os.path.exists(path):
        return path
    os.makedirs(os.path.dirname(path), exist_ok=True)
    print(f"[HandTracker] Downloading the hand detection model (done once) from:\n  {url}")
    urllib.request.urlretrieve(url, path)
    print(f"[HandTracker] Model saved successfully at: {path}")
    return path


class HandTracker:
    def __init__(self, config: dict):
        cam_cfg = config.get("camera", {})
        model_path = cam_cfg.get("model_path") or ensure_model_downloaded()

        options = HandLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=model_path),
            running_mode=VisionRunningMode.VIDEO,
            num_hands=cam_cfg.get("max_num_hands", 1),
            min_hand_detection_confidence=cam_cfg.get("min_detection_confidence", 0.6),
            min_tracking_confidence=cam_cfg.get("min_tracking_confidence", 0.5),
        )
        self.landmarker = HandLandmarker.create_from_options(options)
        self._start_time = time.time()

    def process(self, frame_bgr):
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        timestamp_ms = int((time.time() - self._start_time) * 1000)
        return self.landmarker.detect_for_video(mp_image, timestamp_ms)

    def draw(self, frame_bgr, results):
        if not results.hand_landmarks:
            return frame_bgr
        h, w = frame_bgr.shape[:2]
        for hand_landmarks in results.hand_landmarks:
            pts = [(int(lm.x * w), int(lm.y * h)) for lm in hand_landmarks]
            for a, b in HAND_CONNECTIONS:
                cv2.line(frame_bgr, pts[a], pts[b], (0, 200, 0), 2)
            for x, y in pts:
                cv2.circle(frame_bgr, (x, y), 4, (0, 0, 255), -1)

        # When both hands are seen at the same time, draw the geometric shape between them
        # (the same quadrilateral that TwoHandFrameDetector also builds as an output command)
        if len(results.hand_landmarks) == 2:
            p0 = to_points(results.hand_landmarks[0])
            p1 = to_points(results.hand_landmarks[1])
            quad = compute_pair_quad(p0, p1)
            corners_px = [(int(x * w), int(y * h)) for x, y in quad["corners"]]
            for i in range(4):
                cv2.line(frame_bgr, corners_px[i], corners_px[(i + 1) % 4], (255, 255, 255), 2)
            cx, cy = int(quad["center"][0] * w), int(quad["center"][1] * h)
            cv2.circle(frame_bgr, (cx, cy), 3, (255, 255, 255), -1)

        return frame_bgr

    def close(self):
        self.landmarker.close()
