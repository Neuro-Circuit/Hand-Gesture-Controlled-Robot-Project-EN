import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional


@dataclass
class Command:
    """
    Standard structure of an output command.
    Every detected movement - whether a discrete event (like making a fist) or a full
    hand-rig data frame - is packaged into this class and sent to the output sinks.

    The `code` field: a fixed, unique integer for each command type (starting from zero).
    This code is meant for connecting to simpler systems (e.g. serial communication with
    an Arduino/robotics setup) that only need a single number instead of a full JSON object.
    """
    command_id: str
    code: int
    label_fa: str
    label_en: str
    category: str
    params: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    hand: str = "Right"
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CommandRegistry:
    """
    Central registry of every possible command in the system.
    Each gesture detector registers its command(s) here at load time, with a text
    identifier and a unique numeric code. The Markdown documentation and JSON Schema
    are both generated automatically from this registry.

    Numeric codes are intentionally assigned explicitly right here (next to where each
    command is defined, inside each gestures/*.py file), rather than automatically based
    on import order - so they always stay fixed, predictable, and under the developer's control.
    """
    _registry: Dict[str, Dict[str, Any]] = {}
    _codes_used: Dict[int, str] = {}

    @classmethod
    def register(cls, command_id: str, code: int, label_fa: str, label_en: str,
                 category: str, description: str,
                 params_schema: Optional[Dict[str, str]] = None):
        existing_owner = cls._codes_used.get(code)
        if existing_owner is not None and existing_owner != command_id:
            raise ValueError(
                f"Code conflict: code {code} is already assigned to command '{existing_owner}' "
                f"and cannot also be given to '{command_id}'. Choose a different, unique code."
            )
        cls._codes_used[code] = command_id
        cls._registry[command_id] = {
            "command_id": command_id,
            "code": code,
            "label_fa": label_fa,
            "label_en": label_en,
            "category": category,
            "description": description,
            "params_schema": params_schema or {},
        }

    @classmethod
    def all(cls) -> Dict[str, Dict[str, Any]]:
        return cls._registry

    @classmethod
    def make_command(cls, command_id: str, params: Optional[Dict[str, Any]] = None,
                      confidence: float = 1.0, hand: str = "Right") -> Command:
        """
        Build a full Command from just the text identifier; the rest of the fields
        (code, labels, category) are read automatically from the registry - so each
        command's info is defined in exactly one place (the register call) and never
        duplicated across detector code.
        """
        meta = cls._registry.get(command_id)
        if meta is None:
            raise KeyError(f"Command '{command_id}' is not registered. Register it first with CommandRegistry.register.")
        return Command(
            command_id=command_id,
            code=meta["code"],
            label_fa=meta["label_fa"],
            label_en=meta["label_en"],
            category=meta["category"],
            params=params or {},
            confidence=confidence,
            hand=hand,
        )
