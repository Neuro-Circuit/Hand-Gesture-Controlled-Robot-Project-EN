"""
An example of adding a completely new gesture to the system, without changing any
file in core/. Here, a detector for the "peace" sign (V - index and middle fingers
extended) is added.

Real-world usage:
  1. Place this file (or similar content) in core/gestures/.
  2. In main.py, import PeaceSignDetector and add an instance of it to the list
     returned by build_detectors.
  3. Run it - no changes to dispatcher, hand_tracker, or the main loop are needed.
"""
import os
import sys
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.gesture_base import GestureDetector
from core.command import Command, CommandRegistry
from core.landmarks import finger_states

CommandRegistry.register("hand.peace_sign", 20, "Peace Sign", "Peace Sign", "gesture",
                          "Index and middle fingers are extended, the other fingers are curled in", {})


class PeaceSignDetector(GestureDetector):
    name = "peace_sign"

    def __init__(self, config):
        super().__init__(config)
        self._shown = False

    def reset(self):
        self._shown = False

    def update(self, points, frame_shape, timestamp, hand_label) -> List[Command]:
        states = finger_states(points)
        is_peace = states["index"] and states["middle"] and not states["ring"] and not states["pinky"]

        commands = []
        if is_peace and not self._shown:
            commands.append(CommandRegistry.make_command("hand.peace_sign", hand=hand_label))
        self._shown = is_peace
        return commands


if __name__ == "__main__":
    print("This module is meant to be imported into main.py, not run standalone.")
