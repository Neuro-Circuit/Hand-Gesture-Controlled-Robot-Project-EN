"""
An example of adding a completely new capability that needs both hands at the same
time - without changing any file in core/. Here, the distance between the two hands is
measured, and when they get very close together (palms roughly overlapping) a
"hands.clap" command is emitted.

Real-world usage:
  1. Place this file (or similar content) in core/gestures/.
  2. In main.py, import HandsClapDetector and add an instance of it to the list
     returned by build_two_hand_detectors.
  3. Run it - no changes to dispatcher, hand_tracker, or the main loop are needed.
"""
import os
import sys
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.two_hand_base import TwoHandDetector
from core.command import Command, CommandRegistry
from core.landmarks import palm_center, distance_2d

# Code 21, since codes 0 through 20 are already used in core/gestures/*.py and
# examples/custom_gesture_example.py - every code must be unique
CommandRegistry.register("hands.clap", 21, "Hands Clap", "Hands Clap", "pair",
                          "The two palms come to rest almost on top of each other (very small distance)", {})


class HandsClapDetector(TwoHandDetector):
    name = "hands_clap"

    def __init__(self, config):
        super().__init__(config)
        self.threshold = config.get("hands_clap", {}).get("distance_threshold", 0.08)
        self._clapping = False

    def reset(self):
        self._clapping = False

    def update(self, left_points, right_points, frame_shape, timestamp) -> List[Command]:
        d = distance_2d(palm_center(left_points), palm_center(right_points))
        is_close = d < self.threshold

        commands = []
        if is_close and not self._clapping:
            commands.append(CommandRegistry.make_command("hands.clap", hand="Both"))
        self._clapping = is_close
        return commands


if __name__ == "__main__":
    print("This module is meant to be imported into main.py, not run standalone.")
