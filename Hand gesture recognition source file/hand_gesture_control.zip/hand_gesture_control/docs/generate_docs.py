"""
Running this script generates full documentation for every command registered in the
system, as Markdown and JSON Schema, in this same folder (docs/).

Run:
    python docs/generate_docs.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Import every gesture module so their commands get registered in CommandRegistry
from core.gestures import (  # noqa: E402
    movement, fist, pinch_rub, finger_point, thumbs, open_palm_swipe, hand_rig, two_hand_frame,
)
from core.command import CommandRegistry  # noqa: E402


def generate():
    registry = CommandRegistry.all()
    out_dir = os.path.dirname(__file__)

    schema_path = os.path.join(out_dir, "commands.schema.json")
    with open(schema_path, "w", encoding="utf-8") as f:
        json.dump(registry, f, ensure_ascii=False, indent=2)

    md_path = os.path.join(out_dir, "commands.md")
    lines = [
        "# Hand Gesture Detection System — Command Reference\n",
        f"Total registered commands: **{len(registry)}**\n",
        "Every command has a fixed numeric code starting from zero (suitable for simple "
        "output like serial/Arduino) as well as a human-readable text identifier.\n",
        "| Code | Command ID | Label | Label (alt) | Category | Description | Parameters |",
        "|---|---|---|---|---|---|---|",
    ]
    for cid, meta in sorted(registry.items(), key=lambda kv: kv[1]["code"]):
        params = ", ".join(f"`{k}`: {v}" for k, v in meta["params_schema"].items()) or "-"
        lines.append(f"| **{meta['code']}** | `{cid}` | {meta['label_fa']} | {meta['label_en']} | "
                      f"{meta['category']} | {meta['description']} | {params} |")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"Documentation generated successfully:\n  - {schema_path}\n  - {md_path}\n"
          f"Number of commands: {len(registry)}")


if __name__ == "__main__":
    generate()
